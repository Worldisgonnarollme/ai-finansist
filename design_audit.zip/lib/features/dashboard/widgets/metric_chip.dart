import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_shadows.dart';
import '../../../core/theme/app_text_styles.dart';
import '../../../core/theme/app_theme.dart';

/// One of the two income/expense metric chips below the tax summary card.
class MetricChip extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final bool isPositive;

  const MetricChip({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    required this.isPositive,
  });

  @override
  Widget build(BuildContext context) {
    final valueColor = isPositive ? AppColors.positive : AppColors.negative;
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.sp16 - 2,
        vertical: AppSpacing.sp12,
      ),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppRadius.md),
        // Единственное место в приложении, где карточка приподнята тенью,
        // а не бордером — доход/расход стоят рядом с градиентной hero-
        // карточкой и по замыслу Этапа 3 должны выглядеть чуть весомее
        // «тихих» карточек-строк списков (border-only везде остальном).
        boxShadow: AppShadows.card,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 12, color: valueColor),
              const SizedBox(width: AppSpacing.sp8 - 3),
              Text(label.toUpperCase(), style: AppTextStyles.labelSmall),
            ],
          ),
          const SizedBox(height: AppSpacing.sp8 - 2),
          TweenAnimationBuilder<double>(
            key: ValueKey(value),
            tween: Tween(begin: 0.85, end: 1.0),
            duration: const Duration(milliseconds: 400),
            curve: Curves.easeOut,
            builder: (_, scale, child) => Transform.scale(
              scale: scale,
              alignment: Alignment.centerLeft,
              child: child,
            ),
            child: Text(
              value,
              style: AppTextStyles.amountSmall.copyWith(
                fontSize: 18,
                color: valueColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
