import 'package:flutter/material.dart';

import 'app_colors.dart';

/// На светлой теме карточкам нужна тень или бордер, чтобы отделиться от
/// белого/светлого фона — `AppShadows.card` единственная тень в проекте.
/// Правило: `elevation` виджетов всегда 0; тень — только через
/// [card], либо (для "тихих" карточек) бордер `AppColors.divider` без
/// тени — но не оба одновременно на одной карточке.
class AppShadows {
  AppShadows._();

  static List<BoxShadow> get card => [
    BoxShadow(
      color: AppColors.textPrimary.withValues(alpha: 0.06),
      blurRadius: 24,
      offset: const Offset(0, 8),
    ),
  ];
}
