import 'package:flutter/material.dart';

import 'app_colors.dart';

/// Именованные градиенты — Этап 1 светлого редизайна. `primary` намеренно
/// переиспользует существующую зелёную пару стопов из [AppColors]
/// (зелёный цвет не менялся), а не задаёт новый — чтобы в приложении по
/// прежнему был единственный зелёный градиентный "язык", а не два похожих
/// градиента с разными стопами.
class AppGradients {
  AppGradients._();

  /// Hero-карта налога, primary-кнопки, FAB.
  static const primary = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [AppColors.accentDark, AppColors.accent],
  );

  /// Бары и линии графиков: зелёный -> прозрачный вниз.
  static LinearGradient get chart => LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [AppColors.accent, AppColors.accent.withValues(alpha: 0.06)],
  );

  /// Тёплая бежевая заливка сгруппированных секций.
  static const beigeSection = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Color(0xFFF7F2E7), Color(0xFFF1EAD9)],
  );

  /// Рыжий градиент — ТОЛЬКО бейдж расходов/предупреждений, никогда на
  /// кнопках и больших поверхностях.
  static const warm = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFFF0975F), Color(0xFFE0713A)],
  );
}
