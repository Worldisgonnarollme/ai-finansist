import 'package:firebase_auth/firebase_auth.dart';

/// Тонкая обёртка над FirebaseAuth — инкапсулирует работу с авторизацией,
/// чтобы экраны не обращались к FirebaseAuth напрямую (см. раздел про
/// Firebase Authentication в Yandex Practicum Flutter Handbook).
class UserRepository {
  final FirebaseAuth _firebaseAuth;

  UserRepository([FirebaseAuth? firebaseAuth])
    : _firebaseAuth = firebaseAuth ?? FirebaseAuth.instance;

  bool get isAuthorized => _firebaseAuth.currentUser != null;

  User? get user => _firebaseAuth.currentUser;

  /// Стрим для реактивного отслеживания состояния авторизации (вход/выход).
  Stream<User?> get authStateChanges => _firebaseAuth.authStateChanges();

  Future<void> signInWithEmail(String email, String password) async {
    await _firebaseAuth.signInWithEmailAndPassword(
      email: email,
      password: password,
    );
  }

  Future<void> signUpWithEmail(String email, String password) async {
    await _firebaseAuth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );
  }

  Future<void> signInAnonymously() async {
    await _firebaseAuth.signInAnonymously();
  }

  Future<void> signOut() async {
    await _firebaseAuth.signOut();
  }

  Future<void> sendPasswordResetEmail(String email) async {
    await _firebaseAuth.sendPasswordResetEmail(email: email);
  }

  /// Вход через Google. На вебе открывает всплывающее окно провайдера —
  /// работает без дополнительных пакетов. На мобильных платформах для
  /// продакшена дополнительно потребуется настройка нативного флоу
  /// (SHA-1/URL-схемы в консоли Firebase) — это конфигурация вне кода.
  Future<void> signInWithGoogle() async {
    await _firebaseAuth.signInWithPopup(GoogleAuthProvider());
  }

  /// Шаг 1 телефонного входа — отправляет SMS-код на [phoneNumber]
  /// (формат E.164, напр. "+79251234567"). [codeSent] отдаёт verificationId,
  /// который нужен для подтверждения кода в [signInWithSmsCode].
  Future<void> verifyPhoneNumber({
    required String phoneNumber,
    required void Function(FirebaseAuthException error) onFailed,
    required void Function(String verificationId) codeSent,
  }) {
    return _firebaseAuth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      // На вебе/при мгновенной авто-верификации (Android) вход происходит
      // сразу этим коллбэком, минуя ручной ввод кода.
      verificationCompleted: (credential) async {
        await _firebaseAuth.signInWithCredential(credential);
      },
      verificationFailed: onFailed,
      codeSent: (verificationId, _) => codeSent(verificationId),
      codeAutoRetrievalTimeout: (_) {},
    );
  }

  /// Шаг 2 телефонного входа — подтверждает код, полученный по SMS.
  Future<void> signInWithSmsCode({
    required String verificationId,
    required String smsCode,
  }) async {
    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: smsCode,
    );
    await _firebaseAuth.signInWithCredential(credential);
  }
}
