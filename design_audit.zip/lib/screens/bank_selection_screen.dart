import 'package:flutter/material.dart';
import '../models/bank.dart';
import '../core/theme/app_colors.dart';
import '../core/theme/app_text_styles.dart';
import '../core/theme/app_theme.dart';
import '../widgets/responsive_page.dart';

class BankSelectionScreen extends StatelessWidget {
  const BankSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Подключение банка',
          style: AppTextStyles.headlineMedium.copyWith(fontSize: 18),
        ),
        centerTitle: true,
      ),
      body: ResponsivePage(
        maxWidth: 560,
        child: ListView(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.sp16,
            vertical: AppSpacing.sp8,
          ),
          children: [
            const _SecurityBanner(),
            const SizedBox(height: AppSpacing.sp16),
            for (final bank in kSupportedBanks) ...[
              _BankTile(bank: bank),
              const SizedBox(height: AppSpacing.sp8 + 2),
            ],
          ],
        ),
      ),
    );
  }
}

class _SecurityBanner extends StatelessWidget {
  const _SecurityBanner();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.sp16,
        vertical: AppSpacing.sp12,
      ),
      decoration: BoxDecoration(
        color: AppColors.accentSoft,
        borderRadius: BorderRadius.circular(AppRadius.md),
      ),
      child: Row(
        children: [
          const Icon(Icons.lock_rounded, color: AppColors.accent, size: 20),
          const SizedBox(width: AppSpacing.sp12),
          Expanded(
            child: Text(
              'Мы не храним логины и пароли. Только токен доступа только к выпискам.',
              style: AppTextStyles.bodyMedium.copyWith(
                color: AppColors.accent,
                fontSize: 13,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _BankTile extends StatelessWidget {
  final Bank bank;
  const _BankTile({required this.bank});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () =>
          Navigator.pushNamed(context, '/bank-consent', arguments: bank),
      child: Container(
        padding: const EdgeInsets.all(AppSpacing.sp16),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(AppRadius.md + 2),
          border: Border.all(color: AppColors.divider),
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: bank.color,
                borderRadius: BorderRadius.circular(AppRadius.md),
              ),
              child: Center(
                child: Text(
                  bank.name[0],
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                    color: AppColors.onAccent,
                  ),
                ),
              ),
            ),
            const SizedBox(width: AppSpacing.sp16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          bank.name,
                          style: AppTextStyles.titleMedium.copyWith(
                            fontSize: 16,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (bank.isRecommended) ...[
                        const SizedBox(width: AppSpacing.sp8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: AppSpacing.sp8,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: AppColors.accent,
                            borderRadius: BorderRadius.circular(AppRadius.sm),
                          ),
                          child: const Text(
                            'Рекомендуем',
                            style: TextStyle(
                              color: AppColors.onAccent,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: AppSpacing.sp4),
                  Text(
                    'Подключить выписки',
                    style: AppTextStyles.bodyMedium.copyWith(fontSize: 13),
                  ),
                ],
              ),
            ),
            const Icon(
              Icons.chevron_right_rounded,
              color: AppColors.textTertiary,
            ),
          ],
        ),
      ),
    );
  }
}
