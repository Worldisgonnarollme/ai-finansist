import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../models/bank_statement.dart';
import '../core/theme/app_colors.dart';
import '../core/theme/app_text_styles.dart';
import '../core/theme/app_theme.dart';
import '../main.dart';
import '../widgets/responsive_page.dart';

Future<void> _pickFile(BuildContext context) async {
  final result = await FilePicker.platform.pickFiles(
    type: FileType.custom,
    allowedExtensions: ['csv', 'pdf'],
    withData: true,
  );
  if (result == null || result.files.first.bytes == null) return;
  final file = result.files.first;
  final ext = (file.extension ?? '').toLowerCase();
  if (context.mounted) {
    context.read<AppState>().importFile(
      file.bytes!.toList(),
      ext,
      fileName: file.name,
    );
  }
}

// Список загруженных выписок — вкладка нижней навигации наравне с
// Главной/Историей/Настройками. Загрузить новую выписку можно и отсюда
// (иконка в AppBar / кнопка в пустом состоянии), и одним нажатием с
// главного экрана — оба пути ведут в один и тот же AppState.importFile.
class StatementsScreen extends StatelessWidget {
  const StatementsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final statements = state.statements;
    // См. комментарий в history.dart — тот же расчёт нижнего отступа под
    // плавающую пилюлю на мобильной ветке, статичный на десктопе.
    final isDesktop =
        MediaQuery.sizeOf(context).width >= AppBreakpoints.desktop;
    final bottomPadding = isDesktop
        ? AppSpacing.sp32
        : MediaQuery.paddingOf(context).bottom + AppSpacing.sp16;

    return Scaffold(
      appBar: AppBar(
        title: Text('Выписки', style: AppTextStyles.headlineMedium),
        actions: [
          IconButton(
            onPressed: state.loading ? null : () => _pickFile(context),
            icon: state.loading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: AppColors.accent,
                    ),
                  )
                : const Icon(Icons.upload_file_rounded),
            tooltip: 'Загрузить выписку',
          ),
        ],
      ),
      body: SafeArea(
        bottom: false,
        child: ResponsivePage(
          child: statements.isEmpty
              ? ListView(
                  padding: EdgeInsets.fromLTRB(
                    AppSpacing.sp16,
                    0,
                    AppSpacing.sp16,
                    bottomPadding,
                  ),
                  children: const [_Empty()],
                )
              : ListView.separated(
                  padding: EdgeInsets.fromLTRB(
                    AppSpacing.sp16,
                    AppSpacing.sp8,
                    AppSpacing.sp16,
                    bottomPadding,
                  ),
                  itemCount: statements.length,
                  separatorBuilder: (_, _) =>
                      const SizedBox(height: AppSpacing.sp12),
                  itemBuilder: (_, i) =>
                      _StatementCard(statement: statements[i]),
                ),
        ),
      ),
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.sp48),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.description_outlined,
            size: 48,
            color: AppColors.textSecondary,
          ),
          const SizedBox(height: AppSpacing.sp16),
          Text(
            'Нет загруженных выписок',
            style: AppTextStyles.headlineMedium.copyWith(fontSize: 18),
          ),
          const SizedBox(height: AppSpacing.sp8),
          Text(
            'Загрузите CSV или PDF-выписку из банка,\nчтобы увидеть операции и налог',
            textAlign: TextAlign.center,
            style: AppTextStyles.bodyMedium,
          ),
          const SizedBox(height: AppSpacing.sp24),
          FilledButton.icon(
            onPressed: () => _pickFile(context),
            icon: const Icon(Icons.upload_file_rounded),
            label: const Text('Загрузить выписку'),
          ),
        ],
      ),
    );
  }
}

class _StatementCard extends StatelessWidget {
  final BankStatement statement;
  const _StatementCard({required this.statement});

  IconData get _icon => statement.extension == 'pdf'
      ? Icons.picture_as_pdf_rounded
      : Icons.table_chart_rounded;

  @override
  Widget build(BuildContext context) {
    final date = DateFormat(
      'd MMM yyyy · HH:mm',
      'ru_RU',
    ).format(statement.uploadedAt);
    return Container(
      padding: const EdgeInsets.all(AppSpacing.sp16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppRadius.md),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: AppColors.accentSubtle,
                  borderRadius: BorderRadius.circular(AppRadius.sm),
                ),
                child: Icon(_icon, color: AppColors.accent, size: 20),
              ),
              const SizedBox(width: AppSpacing.sp12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      statement.fileName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: AppTextStyles.titleMedium.copyWith(
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '$date · ${statement.transactionCount} операций',
                      style: AppTextStyles.labelSmall.copyWith(
                        color: AppColors.textSecondary,
                        letterSpacing: 0,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.sp12),
          const Divider(height: 1),
          const SizedBox(height: AppSpacing.sp12),
          Row(
            children: [
              Expanded(
                child: _Metric(
                  label: 'Доходы',
                  value: statement.income.rub,
                  color: AppColors.positive,
                ),
              ),
              const SizedBox(width: AppSpacing.sp24),
              Expanded(
                child: _Metric(
                  label: 'Расходы',
                  value: statement.expenses.rub,
                  color: AppColors.negative,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _Metric({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: AppTextStyles.labelSmall,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: AppTextStyles.titleMedium.copyWith(
            fontWeight: FontWeight.w700,
            color: color,
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }
}
